function person(firstname, lastname) {
    console.log(this);
    this.firstname = 'firstname';
    this.lastname = 'lastname';
    console.log('This function is invoked.');

    

}

person.prototype.getFulName = function(){
    return this.firstname + ' ' + this.lastname
}


var john = new person('John', 'Doe');
console.log(john);


var jane = new person('jane', 'Doe');
console.log(jane);


person.prototype.getFormalFulName = function(){
    return this.firstname + ' ' + this.lastname
}

console.log(john.getFormalFulName());
