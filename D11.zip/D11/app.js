function getPerson() {

    return
    {
firstname: 'Zinab'
    }
}
console.log(getPerson());