function greeet(name) {

console.log('Hello' + name);

}

greeet(' Zinab ');


// using a function expression

var greetFunc = function(name) {
console.log('Hello' + name);

};
greetFunc(' Zinab ');

//using an immediately invoked function expression

var greeting = function(name) {
  return 'Hello' + name;
}(' Zinab ');
console.log(greeting);

var firstname = ' Zinab ';
(function(name) {

var greeting = ' Inside IIFe: Hello';
    console.log( greeting + ' '+ name);

}(firstname)); // IIFE