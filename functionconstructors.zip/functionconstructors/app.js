function person(firstname, lastname) {
    console.log(this);
    this.firstname = 'firstname';
    this.lastname = 'lastname';
    console.log('This function is invoked.');

    

}
var john = new person('John', 'Doe');
console.log(john);


var jane = new person('jane', 'Doe');
console.log(jane);

