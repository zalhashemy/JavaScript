var

// first nae of the person

firstname,


// last name of the person

lastname,

// language
// can be 'en' or 'es'

language;

var person = {

// the first name
firstname:'Zinab',

// the last name
// (always requires)

lastname: 'Alhashemy'

}