// IIFE
(function(global, name) {

    var greetimg = 'Hello';
    global.greetimg = 'Hello';
    console.log(greeting + ' ' + name);

}( window, 'John'));  // IIFE

console.log(greeting);